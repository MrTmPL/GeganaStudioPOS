export interface Employee {
  name: string;
  currentShift?: 1 | 2;
  loginTime?: string;
  logoutTime?: string;
}

export interface BookingSlot {
  id: string;
  customerName: string;
  startTime: string;
  endTime: string;
  price: number;
  paymentMethod: 'cash' | 'transfer' | 'qris' | 'dp' | 'unpaid';
  paymentStatus: 'paid' | 'partial' | 'pending';
  dpAmount?: number;
  remainingAmount?: number;
  date: string;
  status: 'active' | 'completed' | 'cancelled';
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: 'beverage' | 'equipment' | 'penalty';
  stock?: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Transaction {
  id: string;
  items: CartItem[];
  total: number;
  paymentMethod: 'cash' | 'transfer' | 'qris';
  timestamp: string;
  employeeName: string;
  type: 'sale' | 'booking';
  bookingId?: string;
  status: 'completed' | 'cancelled';
}

export interface StockUpdate {
  productId: string;
  quantity: number;
  type: 'add' | 'subtract';
  timestamp: string;
  employeeName: string;
  reason: string;
}