import { Employee, Product } from '../types';

export const employees: Employee[] = [
  { name: 'Dibta' },
  { name: 'Nano' },
  { name: 'Mateo' },
  { name: 'Gandhi' },
  { name: 'Santi' }
];

export const products: Product[] = [
  { id: 'kopi', name: 'Kopi', price: 5000, category: 'beverage', stock: 20 },
  { id: 'teh', name: 'Teh', price: 5000, category: 'beverage', stock: 20 },
  { id: 'air', name: 'Air Putih', price: 5000, category: 'beverage', stock: 30 },
  { id: 'stick', name: 'Stick Drum', price: 25000, category: 'equipment', stock: 10 },
  { id: 'bass', name: 'Denda Senar Bass', price: 50000, category: 'penalty' },
  { id: 'gitar', name: 'Denda Senar Gitar', price: 10000, category: 'penalty' }
];

export const timeSlots = [
  '11:00', '13:00', '15:00', '17:00', '19:00', '21:00', '23:00'
];