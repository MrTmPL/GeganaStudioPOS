import React, { useState, useEffect } from 'react';
import LoginForm from './components/Auth/LoginForm';
import Sidebar from './components/Layout/Sidebar';
import Dashboard from './components/Dashboard/Dashboard';
import BookingStudio from './components/Booking/BookingStudio';
import PointOfSale from './components/POS/PointOfSale';
import StockManagement from './components/Stock/StockManagement';
import Reports from './components/Reports/Reports';
import AttendanceTracker from './components/Attendance/AttendanceTracker';
import { useLocalStorage } from './hooks/useLocalStorage';
import { Transaction, BookingSlot, Employee, CartItem, Product, StockUpdate } from './types';
import { employees as initialEmployees, products as initialProducts } from './data/initial';
import { getCurrentTime } from './utils/dateUtils';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentEmployee, setCurrentEmployee] = useState('');
  const [currentPage, setCurrentPage] = useState('dashboard');
  
  // Data storage
  const [employees, setEmployees] = useLocalStorage<Employee[]>('employees', initialEmployees);
  const [products, setProducts] = useLocalStorage<Product[]>('products', initialProducts);
  const [transactions, setTransactions] = useLocalStorage<Transaction[]>('transactions', []);
  const [bookings, setBookings] = useLocalStorage<BookingSlot[]>('bookings', []);
  const [cart, setCart] = useLocalStorage<CartItem[]>('cart', []);
  const [stockUpdates, setStockUpdates] = useLocalStorage<StockUpdate[]>('stockUpdates', []);

  // Handle login
  const handleLogin = (employeeName: string) => {
    setCurrentEmployee(employeeName);
    setIsAuthenticated(true);
    
    // Auto attendance on login
    handleUpdateAttendance(employeeName, 'login');
  };

  // Handle logout
  const handleLogout = () => {
    // Auto attendance on logout
    handleUpdateAttendance(currentEmployee, 'logout');
    
    setIsAuthenticated(false);
    setCurrentEmployee('');
    setCurrentPage('dashboard');
  };

  // Handle attendance
  const handleUpdateAttendance = (employeeName: string, type: 'login' | 'logout') => {
    const currentTime = getCurrentTime();
    
    setEmployees(prev => prev.map(emp => 
      emp.name === employeeName 
        ? {
            ...emp,
            loginTime: type === 'login' ? currentTime : emp.loginTime,
            logoutTime: type === 'logout' ? currentTime : undefined
          }
        : emp
    ));
  };

  // Handle shift assignment
  const handleSetShift = (employeeName: string, shift: 1 | 2) => {
    setEmployees(prev => prev.map(emp => 
      emp.name === employeeName 
        ? { ...emp, currentShift: shift }
        : emp
    ));
  };
  // Handle new booking
  const handleAddBooking = (bookingData: Omit<BookingSlot, 'id'>) => {
    const newBooking: BookingSlot = {
      ...bookingData,
      id: Date.now().toString()
    };
    
    setBookings(prev => [...prev, newBooking]);
  };

  // Handle booking update
  const handleUpdateBooking = (bookingId: string, updates: Partial<BookingSlot>) => {
    setBookings(prev => prev.map(booking => 
      booking.id === bookingId 
        ? { ...booking, ...updates }
        : booking
    ));
  };
  // Handle transaction completion
  const handleCompleteTransaction = (transactionData: Omit<Transaction, 'id'>) => {
    const newTransaction: Transaction = {
      ...transactionData,
      id: Date.now().toString()
    };
    
    setTransactions(prev => [...prev, newTransaction]);
    
    // Update stock for sold items
    transactionData.items.forEach(item => {
      if (item.product.stock !== undefined) {
        handleUpdateStock(item.product.id, -item.quantity, 'Penjualan');
      }
    });
  };

  // Handle stock update
  const handleUpdateStock = (productId: string, changeOrNewStock: number, reason: string) => {
    setProducts(prev => prev.map(product => 
      product.id === productId 
        ? { 
            ...product, 
            stock: reason === 'Penjualan' 
              ? Math.max(0, (product.stock || 0) + changeOrNewStock)  // changeOrNewStock is negative for sales
              : changeOrNewStock  // changeOrNewStock is the new stock value for manual updates
          }
        : product
    ));

    // Log stock update
    const stockUpdate: StockUpdate = {
      productId,
      quantity: changeOrNewStock,
      type: changeOrNewStock > 0 ? 'add' : 'subtract',
      timestamp: new Date().toISOString(),
      employeeName: currentEmployee,
      reason
    };
    
    setStockUpdates(prev => [...prev, stockUpdate]);
  };

  // Handle adding items to cart
  const handleAddToCart = (items: CartItem[]) => {
    const updatedCart = [...cart];
    
    items.forEach(newItem => {
      const existingIndex = updatedCart.findIndex(
        item => item.product.id === newItem.product.id
      );
      
      if (existingIndex >= 0) {
        updatedCart[existingIndex].quantity += newItem.quantity;
      } else {
        updatedCart.push(newItem);
      }
    });
    
    setCart(updatedCart);
  };

  if (!isAuthenticated) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        onLogout={handleLogout}
        employeeName={currentEmployee}
      />
      
      <div className="flex-1 overflow-auto">
        {currentPage === 'dashboard' && (
          <Dashboard
            transactions={transactions}
            bookings={bookings}
            employeeName={currentEmployee}
          />
        )}
        
        {currentPage === 'booking' && (
          <BookingStudio
            bookings={bookings}
            onAddBooking={handleAddBooking}
            onUpdateBooking={handleUpdateBooking}
            onAddToCart={handleAddToCart}
            employeeName={currentEmployee}
          />
        )}
        
        {currentPage === 'pos' && (
          <PointOfSale
            cart={cart}
            onUpdateCart={setCart}
            onCompleteTransaction={handleCompleteTransaction}
            employeeName={currentEmployee}
          />
        )}
        
        {currentPage === 'stock' && (
          <StockManagement
            products={products}
            onUpdateStock={handleUpdateStock}
            employeeName={currentEmployee}
          />
        )}
        
        {currentPage === 'reports' && (
          <Reports
            transactions={transactions}
            bookings={bookings}
            employees={employees}
          />
        )}
        
        {currentPage === 'attendance' && (
          <AttendanceTracker
            employees={employees}
            onUpdateAttendance={handleUpdateAttendance}
            onSetShift={handleSetShift}
            currentEmployee={currentEmployee}
          />
        )}
      </div>
    </div>
  );
}

export default App;