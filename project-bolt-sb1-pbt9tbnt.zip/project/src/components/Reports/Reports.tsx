import React, { useState } from 'react';
import { FileText, Download, Calendar, DollarSign, TrendingUp } from 'lucide-react';
import { Transaction, BookingSlot, Employee } from '../../types';
import { exportTransactions, exportBookings, exportAttendance } from '../../utils/exportUtils';
import { formatCurrency, getCurrentDate } from '../../utils/dateUtils';

interface ReportsProps {
  transactions: Transaction[];
  bookings: BookingSlot[];
  employees: Employee[];
}

export default function Reports({ transactions, bookings, employees }: ReportsProps) {
  const [selectedDate, setSelectedDate] = useState(getCurrentDate());

  const filteredTransactions = transactions.filter(t => 
    new Date(t.timestamp).toDateString() === new Date(selectedDate).toDateString()
  );

  const filteredBookings = bookings.filter(b => b.date === selectedDate);

  const totalRevenue = filteredTransactions.reduce((sum, t) => sum + t.total, 0);
  const totalBookingRevenue = filteredBookings.reduce((sum, b) => {
    if (b.paymentStatus === 'paid') return sum + b.price;
    if (b.paymentStatus === 'partial') return sum + (b.dpAmount || 0);
    return sum;
  }, 0);

  const paymentMethodStats = transactions.reduce((acc, t) => {
    acc[t.paymentMethod] = (acc[t.paymentMethod] || 0) + t.total;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Laporan</h1>
        <p className="text-gray-600">Lihat dan export laporan transaksi, booking, dan presensi</p>
      </div>

      {/* Date Filter */}
      <div className="mb-8 bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-4">
          <Calendar className="h-5 w-5 text-blue-600" />
          <label className="font-medium text-gray-700">Tanggal:</label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 p-3 rounded-full">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Transaksi</p>
              <p className="text-2xl font-bold text-gray-900">{filteredTransactions.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-3">
            <div className="bg-green-100 p-3 rounded-full">
              <DollarSign className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Pendapatan</p>
              <p className="text-2xl font-bold text-gray-900">
                {formatCurrency(totalRevenue + totalBookingRevenue)}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-3">
            <div className="bg-purple-100 p-3 rounded-full">
              <Calendar className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Booking</p>
              <p className="text-2xl font-bold text-gray-900">{filteredBookings.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-3">
            <div className="bg-orange-100 p-3 rounded-full">
              <TrendingUp className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Avg per Transaksi</p>
              <p className="text-2xl font-bold text-gray-900">
                {filteredTransactions.length > 0 
                  ? formatCurrency(totalRevenue / filteredTransactions.length)
                  : formatCurrency(0)
                }
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Export Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Export Transaksi</h3>
          <p className="text-sm text-gray-600 mb-4">
            Download laporan semua transaksi penjualan dalam format Excel/CSV
          </p>
          <button
            onClick={() => exportTransactions(transactions)}
            className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
          >
            <Download className="h-5 w-5" />
            Download Transaksi
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Export Booking</h3>
          <p className="text-sm text-gray-600 mb-4">
            Download laporan semua booking studio dalam format Excel/CSV
          </p>
          <button
            onClick={() => exportBookings(bookings)}
            className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
          >
            <Download className="h-5 w-5" />
            Download Booking
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Export Presensi</h3>
          <p className="text-sm text-gray-600 mb-4">
            Download laporan presensi karyawan dalam format Excel/CSV
          </p>
          <button
            onClick={() => exportAttendance(employees)}
            className="w-full bg-purple-600 text-white py-3 px-4 rounded-lg hover:bg-purple-700 transition-colors flex items-center justify-center gap-2"
          >
            <Download className="h-5 w-5" />
            Download Presensi
          </button>
        </div>
      </div>

      {/* Detailed Reports */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Metode Pembayaran</h3>
          <div className="space-y-3">
            {Object.entries(paymentMethodStats).map(([method, total]) => (
              <div key={method} className="flex justify-between items-center">
                <span className="capitalize text-gray-700">{method}</span>
                <span className="font-medium text-blue-600">{formatCurrency(total)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Status Booking</h3>
          <div className="space-y-3">
            {['paid', 'partial', 'pending'].map(status => {
              const count = filteredBookings.filter(b => b.paymentStatus === status).length;
              const statusLabel = status === 'paid' ? 'Lunas' : status === 'partial' ? 'DP' : 'Belum Bayar';
              return (
                <div key={status} className="flex justify-between items-center">
                  <span className="text-gray-700">{statusLabel}</span>
                  <span className="font-medium text-blue-600">{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}