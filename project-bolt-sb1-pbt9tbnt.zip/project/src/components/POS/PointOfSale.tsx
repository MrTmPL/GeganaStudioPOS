import React, { useState } from 'react';
import { ShoppingCart, Plus, Minus, X, CreditCard } from 'lucide-react';
import { CartItem, Product, Transaction } from '../../types';
import { products } from '../../data/initial';
import { formatCurrency } from '../../utils/dateUtils';

interface PointOfSaleProps {
  cart: CartItem[];
  onUpdateCart: (cart: CartItem[]) => void;
  onCompleteTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  employeeName: string;
}

export default function PointOfSale({ cart, onUpdateCart, onCompleteTransaction, employeeName }: PointOfSaleProps) {
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'transfer' | 'qris'>('cash');
  const [showPayment, setShowPayment] = useState(false);

  const addToCart = (product: Product) => {
    const existingItem = cart.find(item => item.product.id === product.id);
    
    if (existingItem) {
      const updatedCart = cart.map(item =>
        item.product.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      );
      onUpdateCart(updatedCart);
    } else {
      onUpdateCart([...cart, { product, quantity: 1 }]);
    }
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }

    const updatedCart = cart.map(item =>
      item.product.id === productId
        ? { ...item, quantity }
        : item
    );
    onUpdateCart(updatedCart);
  };

  const removeFromCart = (productId: string) => {
    const updatedCart = cart.filter(item => item.product.id !== productId);
    onUpdateCart(updatedCart);
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;

    const transaction: Omit<Transaction, 'id'> = {
      items: cart,
      total: getTotalPrice(),
      paymentMethod,
      timestamp: new Date().toISOString(),
      employeeName,
      type: 'sale',
      status: 'completed'
    };

    onCompleteTransaction(transaction);
    onUpdateCart([]);
    setShowPayment(false);
    alert('Transaksi berhasil!');
  };

  const categoryGroups = {
    beverage: products.filter(p => p.category === 'beverage'),
    equipment: products.filter(p => p.category === 'equipment'),
    penalty: products.filter(p => p.category === 'penalty')
  };

  const categoryNames = {
    beverage: 'Minuman',
    equipment: 'Peralatan',
    penalty: 'Denda'
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Point of Sale</h1>
        <p className="text-gray-600">Kelola penjualan dan transaksi</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Products */}
        <div className="lg:col-span-2 space-y-6">
          {Object.entries(categoryGroups).map(([category, items]) => (
            <div key={category} className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">
                {categoryNames[category as keyof typeof categoryNames]}
              </h2>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {items.map(product => (
                  <div
                    key={product.id}
                    className="border border-gray-200 rounded-lg p-4 hover:border-blue-500 transition-colors cursor-pointer"
                    onClick={() => addToCart(product)}
                  >
                    <h3 className="font-medium text-gray-900 mb-2">{product.name}</h3>
                    <p className="text-lg font-bold text-blue-600 mb-2">
                      {formatCurrency(product.price)}
                    </p>
                    {product.stock !== undefined && (
                      <p className="text-sm text-gray-600 mb-3">Stock: {product.stock}</p>
                    )}
                    <button className="w-full bg-blue-600 text-white py-2 px-3 rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center gap-1">
                      <Plus className="h-4 w-4" />
                      Tambah
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Cart */}
        <div className="bg-white rounded-xl shadow-md p-6 h-fit">
          <div className="flex items-center gap-2 mb-6">
            <ShoppingCart className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">Keranjang</h2>
          </div>

          {cart.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Keranjang kosong</p>
          ) : (
            <>
              <div className="space-y-3 mb-6 max-h-96 overflow-y-auto">
                {cart.map(item => (
                  <div key={item.product.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 text-sm">{item.product.name}</h4>
                      <p className="text-sm text-gray-600">
                        {formatCurrency(item.product.price)} x {item.quantity}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
                      >
                        <Minus className="h-4 w-4" />
                      </button>
                      <span className="w-8 text-center font-medium">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center hover:bg-red-200 text-red-600 ml-2"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t border-gray-200 pt-4">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-lg font-semibold text-gray-900">Total:</span>
                  <span className="text-xl font-bold text-blue-600">
                    {formatCurrency(getTotalPrice())}
                  </span>
                </div>

                {!showPayment ? (
                  <button
                    onClick={() => setShowPayment(true)}
                    className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                  >
                    <CreditCard className="h-5 w-5" />
                    Proses Pembayaran
                  </button>
                ) : (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Metode Pembayaran
                      </label>
                      <div className="space-y-2">
                        {['cash', 'transfer', 'qris'].map(method => (
                          <label key={method} className="flex items-center">
                            <input
                              type="radio"
                              name="paymentMethod"
                              value={method}
                              checked={paymentMethod === method}
                              onChange={(e) => setPaymentMethod(e.target.value as any)}
                              className="mr-2"
                            />
                            <span className="capitalize">
                              {method === 'qris' ? 'QRIS' : method}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => setShowPayment(false)}
                        className="flex-1 bg-gray-200 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors"
                      >
                        Batal
                      </button>
                      <button
                        onClick={handleCheckout}
                        className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors"
                      >
                        Bayar
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}