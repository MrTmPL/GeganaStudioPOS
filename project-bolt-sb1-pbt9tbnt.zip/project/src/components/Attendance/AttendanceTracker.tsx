import React from 'react';
import { Users, Clock, LogIn, LogOut, UserCheck } from 'lucide-react';
import { Employee } from '../../types';
import { getCurrentTime } from '../../utils/dateUtils';

interface AttendanceTrackerProps {
  employees: Employee[];
  onUpdateAttendance: (employeeName: string, type: 'login' | 'logout') => void;
  onSetShift: (employeeName: string, shift: 1 | 2) => void;
  currentEmployee: string;
}

export default function AttendanceTracker({ employees, onUpdateAttendance, onSetShift, currentEmployee }: AttendanceTrackerProps) {
  const currentTime = getCurrentTime();

  const getShiftInfo = (shift: 1 | 2) => {
    return shift === 1 ? '11:00 - 18:00' : '18:00 - 01:00';
  };

  const getCurrentShiftTime = () => {
    const hour = new Date().getHours();
    return (hour >= 11 && hour < 18) ? 1 : 2;
  };

  const currentShiftTime = getCurrentShiftTime();

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Presensi Karyawan</h1>
        <p className="text-gray-600">Kelola presensi masuk dan keluar karyawan</p>
      </div>

      {/* Current Time */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl shadow-md p-6 text-white mb-8">
        <div className="flex items-center gap-3">
          <Clock className="h-8 w-8" />
          <div>
            <h2 className="text-xl font-semibold">Waktu Saat Ini</h2>
            <p className="text-3xl font-bold">{currentTime}</p>
            <p className="text-lg">Shift {currentShiftTime} ({getShiftInfo(currentShiftTime)})</p>
          </div>
        </div>
      </div>

      {/* Employee List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {employees.map(employee => {
          const isLoggedIn = !!employee.loginTime && !employee.logoutTime;
          const hasShiftSet = !!employee.currentShift;
          
          return (
            <div 
              key={employee.name} 
              className={`bg-white rounded-xl shadow-md p-6 border-2 ${
                employee.name === currentEmployee ? 'border-blue-500' : 'border-transparent'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Users className="h-8 w-8 text-blue-600" />
                  <div>
                    <h3 className="font-semibold text-gray-900">{employee.name}</h3>
                    {hasShiftSet ? (
                      <p className="text-sm text-gray-600">
                        Shift {employee.currentShift} ({getShiftInfo(employee.currentShift!)})
                      </p>
                    ) : (
                      <p className="text-sm text-orange-600">Pilih shift terlebih dahulu</p>
                    )}
                  </div>
                </div>
                {isLoggedIn && (
                  <div className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Online
                  </div>
                )}
              </div>

              {!hasShiftSet && (
                <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm text-blue-800 mb-2">Pilih Shift:</p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => onSetShift(employee.name, 1)}
                      className="flex-1 bg-blue-600 text-white py-1 px-2 rounded text-xs hover:bg-blue-700"
                    >
                      Shift 1
                    </button>
                    <button
                      onClick={() => onSetShift(employee.name, 2)}
                      className="flex-1 bg-purple-600 text-white py-1 px-2 rounded text-xs hover:bg-purple-700"
                    >
                      Shift 2
                    </button>
                  </div>
                </div>
              )}

              <div className="space-y-3 mb-4">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Masuk:</span>
                  <span className="text-sm font-medium">
                    {employee.loginTime || '-'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Keluar:</span>
                  <span className="text-sm font-medium">
                    {employee.logoutTime || '-'}
                  </span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => onUpdateAttendance(employee.name, 'login')}
                  disabled={isLoggedIn || !hasShiftSet}
                  className="flex-1 bg-green-600 text-white py-2 px-3 rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-1 text-sm"
                >
                  <LogIn className="h-4 w-4" />
                  Masuk
                </button>
                <button
                  onClick={() => onUpdateAttendance(employee.name, 'logout')}
                  disabled={!isLoggedIn}
                  className="flex-1 bg-red-600 text-white py-2 px-3 rounded-lg hover:bg-red-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-1 text-sm"
                >
                  <LogOut className="h-4 w-4" />
                  Keluar
                </button>
              </div>

              {employee.name === currentEmployee && (
                <div className="mt-3 p-2 bg-blue-50 rounded-lg">
                  <p className="text-xs text-blue-800 text-center font-medium">
                    Anda sedang login
                  </p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Shift Information */}
      <div className="mt-8 bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Informasi Shift</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-blue-50 rounded-lg">
            <h3 className="font-medium text-blue-900 mb-2">Shift 1 (11:00 - 18:00)</h3>
            <ul className="text-sm text-blue-800">
              {employees.filter(e => e.currentShift === 1).map(e => (
                <li key={e.name}>• {e.name}</li>
              ))}
              {employees.filter(e => e.currentShift === 1).length === 0 && (
                <li className="text-gray-500">Belum ada karyawan</li>
              )}
            </ul>
          </div>
          <div className="p-4 bg-purple-50 rounded-lg">
            <h3 className="font-medium text-purple-900 mb-2">Shift 2 (18:00 - 01:00)</h3>
            <ul className="text-sm text-purple-800">
              {employees.filter(e => e.currentShift === 2).map(e => (
                <li key={e.name}>• {e.name}</li>
              ))}
              {employees.filter(e => e.currentShift === 2).length === 0 && (
                <li className="text-gray-500">Belum ada karyawan</li>
              )}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}