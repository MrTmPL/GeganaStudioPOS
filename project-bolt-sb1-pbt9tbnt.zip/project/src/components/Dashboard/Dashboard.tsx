import React from 'react';
import { 
  Calendar, 
  ShoppingCart, 
  TrendingUp, 
  Users,
  Clock,
  DollarSign
} from 'lucide-react';
import { Transaction, BookingSlot } from '../../types';
import { formatCurrency, getCurrentTime } from '../../utils/dateUtils';

interface DashboardProps {
  transactions: Transaction[];
  bookings: BookingSlot[];
  employeeName: string;
}

export default function Dashboard({ transactions, bookings, employeeName }: DashboardProps) {
  const todayTransactions = transactions.filter(t => 
    new Date(t.timestamp).toDateString() === new Date().toDateString()
  );

  const todayRevenue = todayTransactions.reduce((sum, t) => sum + t.total, 0);
  const todayBookings = bookings.filter(b => b.date === new Date().toISOString().split('T')[0]);
  const activeBookings = todayBookings.filter(b => b.status === 'active');

  const stats = [
    {
      title: 'Booking Hari Ini',
      value: todayBookings.length.toString(),
      icon: Calendar,
      color: 'bg-blue-500',
      change: '+12%'
    },
    {
      title: 'Transaksi Hari Ini',
      value: todayTransactions.length.toString(),
      icon: ShoppingCart,
      color: 'bg-green-500',
      change: '+8%'
    },
    {
      title: 'Pendapatan Hari Ini',
      value: formatCurrency(todayRevenue),
      icon: DollarSign,
      color: 'bg-purple-500',
      change: '+15%'
    },
    {
      title: 'Booking Aktif',
      value: activeBookings.length.toString(),
      icon: Users,
      color: 'bg-orange-500',
      change: '0%'
    }
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">
          Selamat datang, {employeeName}! Berikut ringkasan aktivitas hari ini.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-2">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-full`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <span className="text-sm font-medium text-green-600">{stat.change}</span>
                <span className="text-sm text-gray-600 ml-2">dari minggu lalu</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Current Time and Shift Info */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl shadow-md p-6 text-white">
          <div className="flex items-center gap-3">
            <Clock className="h-8 w-8" />
            <div>
              <h3 className="text-lg font-semibold">Waktu Saat Ini</h3>
              <p className="text-2xl font-bold">{getCurrentTime()}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Studio Status</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Total Slot:</span>
              <span className="font-medium">7 slot</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Terboking:</span>
              <span className="font-medium text-blue-600">{todayBookings.length} slot</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Tersedia:</span>
              <span className="font-medium text-green-600">{7 - todayBookings.length} slot</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="space-y-2">
            <button className="w-full bg-blue-50 hover:bg-blue-100 text-blue-700 py-2 px-4 rounded-lg text-sm font-medium transition-colors">
              Booking Baru
            </button>
            <button className="w-full bg-green-50 hover:bg-green-100 text-green-700 py-2 px-4 rounded-lg text-sm font-medium transition-colors">
              Transaksi Baru
            </button>
            <button className="w-full bg-orange-50 hover:bg-orange-100 text-orange-700 py-2 px-4 rounded-lg text-sm font-medium transition-colors">
              Update Stock
            </button>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Booking Terbaru</h3>
          <div className="space-y-3">
            {todayBookings.slice(0, 5).map((booking) => (
              <div key={booking.id} className="flex items-center justify-between py-2 border-b border-gray-100">
                <div>
                  <p className="font-medium text-gray-900">{booking.customerName}</p>
                  <p className="text-sm text-gray-600">{booking.startTime} - {booking.endTime}</p>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  booking.paymentStatus === 'paid' ? 'bg-green-100 text-green-800' :
                  booking.paymentStatus === 'partial' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {booking.paymentStatus}
                </span>
              </div>
            ))}
            {todayBookings.length === 0 && (
              <p className="text-gray-500 text-center py-4">Belum ada booking hari ini</p>
            )}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Transaksi Terbaru</h3>
          <div className="space-y-3">
            {todayTransactions.slice(0, 5).map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between py-2 border-b border-gray-100">
                <div>
                  <p className="font-medium text-gray-900">{formatCurrency(transaction.total)}</p>
                  <p className="text-sm text-gray-600">
                    {new Date(transaction.timestamp).toLocaleTimeString('id-ID')}
                  </p>
                </div>
                <span className="text-sm font-medium text-blue-600">
                  {transaction.paymentMethod}
                </span>
              </div>
            ))}
            {todayTransactions.length === 0 && (
              <p className="text-gray-500 text-center py-4">Belum ada transaksi hari ini</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}