import React, { useState } from 'react';
import { Calendar, Clock, User, CreditCard, Plus, AlertCircle, CheckCircle } from 'lucide-react';
import { BookingSlot, CartItem } from '../../types';
import { timeSlots } from '../../data/initial';
import { formatCurrency, getCurrentDate, addHours } from '../../utils/dateUtils';

interface BookingStudioProps {
  bookings: BookingSlot[];
  onAddBooking: (booking: Omit<BookingSlot, 'id'>) => void;
  onUpdateBooking: (bookingId: string, updates: Partial<BookingSlot>) => void;
  onAddToCart: (items: CartItem[]) => void;
  employeeName: string;
}

export default function BookingStudio({ bookings, onAddBooking, onUpdateBooking, onAddToCart, employeeName }: BookingStudioProps) {
  const [customerName, setCustomerName] = useState('');
  const [selectedDate, setSelectedDate] = useState(getCurrentDate());
  const [selectedTime, setSelectedTime] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'transfer' | 'qris' | 'dp' | 'unpaid'>('cash');
  const [dpAmount, setDpAmount] = useState(0);
  const [collectingPayment, setCollectingPayment] = useState<string | null>(null);
  const [collectionMethod, setCollectionMethod] = useState<'cash' | 'transfer' | 'qris'>('cash');

  const studioPrice = 85000;

  const getCurrentTime = () => {
    const now = new Date();
    return `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
  };

  const isSessionEnded = (booking: BookingSlot) => {
    if (booking.date !== getCurrentDate()) return false;
    const currentTime = getCurrentTime();
    return currentTime >= booking.endTime;
  };

  const needsPaymentCollection = (booking: BookingSlot) => {
    return isSessionEnded(booking) && 
           (booking.paymentStatus === 'partial' || booking.paymentStatus === 'pending');
  };

  const getBookedSlots = () => {
    return bookings
      .filter(b => b.date === selectedDate && b.status === 'active')
      .map(b => b.startTime);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !selectedTime) return;

    const endTime = addHours(selectedTime, 2);
    const bookingId = Date.now().toString();

    let paymentStatus: 'paid' | 'partial' | 'pending';
    let remainingAmount = 0;

    if (paymentMethod === 'dp') {
      paymentStatus = 'partial';
      remainingAmount = studioPrice - dpAmount;
    } else if (paymentMethod === 'unpaid') {
      paymentStatus = 'pending';
      remainingAmount = studioPrice;
    } else {
      paymentStatus = 'paid';
    }

    const booking: Omit<BookingSlot, 'id'> = {
      customerName,
      startTime: selectedTime,
      endTime,
      price: studioPrice,
      paymentMethod,
      paymentStatus,
      dpAmount: paymentMethod === 'dp' ? dpAmount : undefined,
      remainingAmount,
      date: selectedDate,
      status: 'active'
    };

    onAddBooking(booking);

    // Add to cart for POS integration
    const cartItem: CartItem = {
      product: {
        id: `booking-${bookingId}`,
        name: `Studio Booking - ${customerName} (${selectedTime}-${endTime})`,
        price: studioPrice,
        category: 'equipment'
      },
      quantity: 1
    };

    onAddToCart([cartItem]);

    // Reset form
    setCustomerName('');
    setSelectedTime('');
    setPaymentMethod('cash');
    setDpAmount(0);

    alert('Booking berhasil ditambahkan!');
  };

  const handleCollectPayment = (bookingId: string) => {
    const booking = bookings.find(b => b.id === bookingId);
    if (!booking) return;

    const remainingAmount = booking.remainingAmount || 0;
    
    onUpdateBooking(bookingId, {
      paymentStatus: 'paid',
      paymentMethod: collectionMethod,
      remainingAmount: 0
    });

    // Add to cart for transaction record
    const cartItem: CartItem = {
      product: {
        id: `payment-${bookingId}`,
        name: `Pelunasan Booking - ${booking.customerName}`,
        price: remainingAmount,
        category: 'equipment'
      },
      quantity: 1
    };

    onAddToCart([cartItem]);
    setCollectingPayment(null);
    alert('Pembayaran berhasil ditagih!');
  };

  const bookedSlots = getBookedSlots();

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Booking Studio</h1>
        <p className="text-gray-600">Kelola booking studio music untuk pelanggan</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Booking Form */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Form Booking</h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <User className="inline h-4 w-4 mr-1" />
                Nama Customer
              </label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Masukkan nama customer"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="inline h-4 w-4 mr-1" />
                Tanggal
              </label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                min={getCurrentDate()}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Clock className="inline h-4 w-4 mr-1" />
                Jam Latihan (2 jam per sesi)
              </label>
              <div className="grid grid-cols-2 gap-3">
                {timeSlots.map(time => (
                  <button
                    key={time}
                    type="button"
                    onClick={() => setSelectedTime(time)}
                    disabled={bookedSlots.includes(time)}
                    className={`p-3 rounded-lg border text-sm font-medium transition-colors ${
                      selectedTime === time
                        ? 'bg-blue-600 text-white border-blue-600'
                        : bookedSlots.includes(time)
                        ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed'
                        : 'bg-white text-gray-700 border-gray-300 hover:border-blue-500'
                    }`}
                  >
                    {time} - {addHours(time, 2)}
                    {bookedSlots.includes(time) && (
                      <div className="text-xs mt-1">Terboking</div>
                    )}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">Detail Harga</h3>
              <div className="flex justify-between">
                <span>Studio (2 jam):</span>
                <span className="font-medium">{formatCurrency(studioPrice)}</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <CreditCard className="inline h-4 w-4 mr-1" />
                Metode Pembayaran
              </label>
              <div className="space-y-2">
                {['cash', 'transfer', 'qris', 'dp', 'unpaid'].map(method => (
                  <label key={method} className="flex items-center">
                    <input
                      type="radio"
                      name="paymentMethod"
                      value={method}
                      checked={paymentMethod === method}
                      onChange={(e) => setPaymentMethod(e.target.value as any)}
                      className="mr-3"
                    />
                    <span className="capitalize">
                      {method === 'dp' ? 'Down Payment (DP)' : 
                       method === 'unpaid' ? 'Belum Bayar' : 
                       method === 'qris' ? 'QRIS' : method}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {paymentMethod === 'dp' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Jumlah DP
                </label>
                <input
                  type="number"
                  value={dpAmount}
                  onChange={(e) => setDpAmount(Number(e.target.value))}
                  max={studioPrice}
                  min={0}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Masukkan jumlah DP"
                />
                <p className="text-sm text-gray-600 mt-1">
                  Sisa: {formatCurrency(studioPrice - dpAmount)}
                </p>
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              <Plus className="h-5 w-5" />
              Tambah Booking
            </button>
          </form>
        </div>

        {/* Schedule Overview */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Jadwal Studio</h2>
          
          <div className="mb-4">
            <h3 className="font-medium text-gray-700 mb-2">
              {new Date(selectedDate).toLocaleDateString('id-ID', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </h3>
          </div>

          <div className="space-y-3">
            {timeSlots.map(time => {
              const booking = bookings.find(b => 
                b.date === selectedDate && 
                b.startTime === time && 
                b.status === 'active'
              );

              const needsCollection = booking && needsPaymentCollection(booking);
              const sessionEnded = booking && isSessionEnded(booking);
              return (
                <div
                  key={time}
                  className={`p-4 rounded-lg border-2 ${
                    needsCollection
                      ? 'bg-orange-50 border-orange-300'
                      : booking 
                      ? 'bg-red-50 border-red-200' 
                      : 'bg-green-50 border-green-200'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-medium">
                        {time} - {addHours(time, 2)}
                      </span>
                      {booking && (
                        <div className="text-sm text-gray-600 mt-1">
                          <div>Customer: {booking.customerName}</div>
                          <div className="flex items-center gap-2">
                            <span>Status:</span>
                            <span className={`px-2 py-1 rounded text-xs ${
                              booking.paymentStatus === 'paid' ? 'bg-green-100 text-green-800' :
                              booking.paymentStatus === 'partial' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {booking.paymentStatus === 'paid' ? 'Lunas' :
                               booking.paymentStatus === 'partial' ? `DP ${formatCurrency(booking.dpAmount || 0)}` :
                               'Belum Bayar'}
                            </span>
                            {sessionEnded && (
                              <span className="px-2 py-1 rounded text-xs bg-gray-100 text-gray-800">
                                Selesai
                              </span>
                            )}
                          </div>
                          {needsCollection && (
                            <div className="mt-2 p-2 bg-orange-100 rounded">
                              <div className="flex items-center gap-1 text-orange-800 text-xs mb-2">
                                <AlertCircle className="h-3 w-3" />
                                <span>Perlu ditagih: {formatCurrency(booking.remainingAmount || 0)}</span>
                              </div>
                              {collectingPayment === booking.id ? (
                                <div className="space-y-2">
                                  <select
                                    value={collectionMethod}
                                    onChange={(e) => setCollectionMethod(e.target.value as any)}
                                    className="w-full text-xs p-1 border rounded"
                                  >
                                    <option value="cash">Cash</option>
                                    <option value="transfer">Transfer</option>
                                    <option value="qris">QRIS</option>
                                  </select>
                                  <div className="flex gap-1">
                                    <button
                                      onClick={() => handleCollectPayment(booking.id)}
                                      className="flex-1 bg-green-600 text-white py-1 px-2 rounded text-xs hover:bg-green-700"
                                    >
                                      Tagih
                                    </button>
                                    <button
                                      onClick={() => setCollectingPayment(null)}
                                      className="flex-1 bg-gray-400 text-white py-1 px-2 rounded text-xs hover:bg-gray-500"
                                    >
                                      Batal
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <button
                                  onClick={() => setCollectingPayment(booking.id)}
                                  className="bg-orange-600 text-white py-1 px-2 rounded text-xs hover:bg-orange-700"
                                >
                                  Tagih Pembayaran
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      needsCollection
                        ? 'bg-orange-100 text-orange-800'
                        : booking 
                        ? 'bg-red-100 text-red-800' 
                        : 'bg-green-100 text-green-800'
                    }`}>
                      {needsCollection ? 'Perlu Tagih' : booking ? 'Terboking' : 'Tersedia'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}