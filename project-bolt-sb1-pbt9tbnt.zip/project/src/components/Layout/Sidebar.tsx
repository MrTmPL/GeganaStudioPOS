import React from 'react';
import { 
  Home, 
  Calendar, 
  ShoppingCart, 
  Package, 
  FileText, 
  Users, 
  LogOut,
  Music
} from 'lucide-react';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  onLogout: () => void;
  employeeName: string;
}

const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: Home },
  { id: 'booking', label: 'Booking Studio', icon: Calendar },
  { id: 'pos', label: 'Point of Sale', icon: ShoppingCart },
  { id: 'stock', label: 'Manajemen Stock', icon: Package },
  { id: 'reports', label: 'Laporan', icon: FileText },
  { id: 'attendance', label: 'Presensi', icon: Users }
];

export default function Sidebar({ currentPage, onPageChange, onLogout, employeeName }: SidebarProps) {
  return (
    <div className="bg-slate-900 text-white w-64 min-h-screen flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-slate-700">
        <div className="flex items-center gap-3">
          <Music className="h-8 w-8 text-blue-400" />
          <div>
            <h1 className="font-bold text-lg">Gegana Music</h1>
            <p className="text-sm text-slate-400">Studio POS System</p>
          </div>
        </div>
      </div>

      {/* User Info */}
      <div className="p-4 border-b border-slate-700">
        <div className="text-sm">
          <span className="text-slate-400">Logged in as:</span>
          <p className="font-medium text-blue-400">{employeeName}</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.id}>
                <button
                  onClick={() => onPageChange(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    currentPage === item.id
                      ? 'bg-blue-600 text-white'
                      : 'hover:bg-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  {item.label}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Logout */}
      <div className="p-4 border-t border-slate-700">
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-slate-300 hover:text-white hover:bg-red-600 transition-colors"
        >
          <LogOut className="h-5 w-5" />
          Logout
        </button>
      </div>
    </div>
  );
}