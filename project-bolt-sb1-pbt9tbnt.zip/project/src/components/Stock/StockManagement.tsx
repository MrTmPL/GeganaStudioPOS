import React, { useState } from 'react';
import { Package, Plus, Minus, Save, AlertTriangle } from 'lucide-react';
import { Product, StockUpdate } from '../../types';

interface StockManagementProps {
  products: Product[];
  onUpdateStock: (productId: string, newStock: number, reason: string) => void;
  employeeName: string;
}

export default function StockManagement({ products, onUpdateStock, employeeName }: StockManagementProps) {
  const [stockChanges, setStockChanges] = useState<{[key: string]: number}>({});
  const [reasons, setReasons] = useState<{[key: string]: string}>({});

  const handleStockChange = (productId: string, change: number) => {
    setStockChanges(prev => ({
      ...prev,
      [productId]: (prev[productId] || 0) + change
    }));
  };

  const handleSaveStock = (productId: string) => {
    const change = stockChanges[productId] || 0;
    const reason = reasons[productId] || '';
    
    if (change === 0) {
      alert('Tidak ada perubahan stock');
      return;
    }

    if (!reason.trim()) {
      alert('Alasan perubahan stock harus diisi');
      return;
    }

    const product = products.find(p => p.id === productId);
    if (product && product.stock !== undefined) {
      const newStock = Math.max(0, product.stock + change);
      onUpdateStock(productId, newStock, reason);
      
      // Reset changes
      setStockChanges(prev => ({ ...prev, [productId]: 0 }));
      setReasons(prev => ({ ...prev, [productId]: '' }));
      
      alert('Stock berhasil diupdate');
    }
  };

  const stockProducts = products.filter(p => p.stock !== undefined);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Manajemen Stock</h1>
        <p className="text-gray-600">Kelola stock minuman dan peralatan</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {stockProducts.map(product => {
          const change = stockChanges[product.id] || 0;
          const newStock = (product.stock || 0) + change;
          const isLowStock = (product.stock || 0) < 5;

          return (
            <div key={product.id} className="bg-white rounded-xl shadow-md p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Package className="h-8 w-8 text-blue-600" />
                  <div>
                    <h3 className="font-semibold text-gray-900">{product.name}</h3>
                    <p className="text-sm text-gray-600">Rp {product.price.toLocaleString()}</p>
                  </div>
                </div>
                {isLowStock && (
                  <AlertTriangle className="h-6 w-6 text-orange-500" />
                )}
              </div>

              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Stock Saat Ini:</span>
                  <span className={`font-bold ${isLowStock ? 'text-orange-600' : 'text-green-600'}`}>
                    {product.stock}
                  </span>
                </div>
                
                {change !== 0 && (
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Stock Baru:</span>
                    <span className={`font-medium ${newStock < 5 ? 'text-orange-600' : 'text-blue-600'}`}>
                      {newStock}
                    </span>
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-center gap-4">
                  <button
                    onClick={() => handleStockChange(product.id, -1)}
                    className="w-10 h-10 bg-red-100 text-red-600 rounded-full flex items-center justify-center hover:bg-red-200 transition-colors"
                  >
                    <Minus className="h-5 w-5" />
                  </button>
                  
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-bold text-gray-900">{change}</span>
                  </div>
                  
                  <button
                    onClick={() => handleStockChange(product.id, 1)}
                    className="w-10 h-10 bg-green-100 text-green-600 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors"
                  >
                    <Plus className="h-5 w-5" />
                  </button>
                </div>

                <input
                  type="text"
                  placeholder="Alasan perubahan stock..."
                  value={reasons[product.id] || ''}
                  onChange={(e) => setReasons(prev => ({ ...prev, [product.id]: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
                />

                <button
                  onClick={() => handleSaveStock(product.id)}
                  disabled={change === 0 || !reasons[product.id]?.trim()}
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <Save className="h-4 w-4" />
                  Update Stock
                </button>
              </div>

              {isLowStock && (
                <div className="mt-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-orange-600" />
                    <span className="text-sm text-orange-800 font-medium">Stock Menipis!</span>
                  </div>
                  <p className="text-xs text-orange-700 mt-1">Segera lakukan restock</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-8 bg-white rounded-xl shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Panduan Stock Management</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-blue-50 rounded-lg">
            <h3 className="font-medium text-blue-900 mb-2">Awal Shift</h3>
            <p className="text-sm text-blue-800">
              Periksa dan update stock semua item sebelum memulai layanan
            </p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg">
            <h3 className="font-medium text-green-900 mb-2">Akhir Shift</h3>
            <p className="text-sm text-green-800">
              Catat penggunaan stock dan lakukan perhitungan ulang
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}