import { Transaction, BookingSlot, Employee } from '../types';

export const exportToExcel = (data: any[], filename: string) => {
  const csvContent = convertToCSV(data);
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

const convertToCSV = (data: any[]): string => {
  if (data.length === 0) return '';
  
  const headers = Object.keys(data[0]).join(',');
  const rows = data.map(obj => 
    Object.values(obj).map(val => 
      typeof val === 'string' && val.includes(',') ? `"${val}"` : val
    ).join(',')
  );
  
  return [headers, ...rows].join('\n');
};

export const exportTransactions = (transactions: Transaction[]) => {
  const exportData = transactions.map(t => ({
    ID: t.id,
    Timestamp: t.timestamp,
    Employee: t.employeeName,
    Type: t.type,
    Items: t.items.map(i => `${i.product.name} (${i.quantity})`).join('; '),
    Total: t.total,
    PaymentMethod: t.paymentMethod,
    Status: t.status
  }));
  
  exportToExcel(exportData, 'transactions');
};

export const exportBookings = (bookings: BookingSlot[]) => {
  const exportData = bookings.map(b => ({
    ID: b.id,
    Customer: b.customerName,
    Date: b.date,
    StartTime: b.startTime,
    EndTime: b.endTime,
    Price: b.price,
    PaymentMethod: b.paymentMethod,
    PaymentStatus: b.paymentStatus,
    DPAmount: b.dpAmount || 0,
    RemainingAmount: b.remainingAmount || 0,
    Status: b.status
  }));
  
  exportToExcel(exportData, 'bookings');
};

export const exportAttendance = (employees: Employee[]) => {
  const exportData = employees.map(e => ({
    Name: e.name,
    CurrentShift: e.currentShift || 'Not Set',
    LoginTime: e.loginTime || 'Not logged in',
    LogoutTime: e.logoutTime || 'Not logged out',
    Date: new Date().toISOString().split('T')[0]
  }));
  
  exportToExcel(exportData, 'attendance');
};